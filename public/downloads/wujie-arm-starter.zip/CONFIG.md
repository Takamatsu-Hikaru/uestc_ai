# 模型配置

官网 [API 平台](/api-platform) 提供本队 C 题的模型名称与 Key。填写 config.json 的 model，并设置 UESTC_MODEL_API_KEY。默认 agent.py 会调用模型；max_output_tokens、thinking 和 api_timeout 控制单次请求。测评时平台自动注入凭据。

每个场景开始调用 reset(goal)，默认示例清空该场景的记忆。开发和提交操作见 README.md。
